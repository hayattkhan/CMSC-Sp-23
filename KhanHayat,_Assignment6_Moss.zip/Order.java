package A2;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

import A2.Beverage.Day;
import A2.Beverage.Size;
import A2.Beverage.Type;

public class Order implements OrderInterface, Comparable<Order> {
	// instance variables
	private int orderNumber = 0;
	private LocalDateTime orderTime;
	private Day orderDay;
	private Customer customer;
	private List<Beverage> beverages;

//	Copy code
	// generate random order number within range 10000 to 90000
	public static int generateRandomOrderNumber() {
	    Random random = new Random();
	    return random.nextInt(80000) + 10000;
	}

	// constructor
	public Order(int orderNumber, LocalDateTime orderTime, Day orderDay, Customer customer, List<Beverage> beverages) {
	    this.orderNumber = orderNumber;
	    this.orderTime = orderTime;
	    this.orderDay = orderDay;
	    this.customer = customer;
	    this.beverages = beverages;
	}

	public Order(int time, Day day, String customerName, int customerAge) {
		this.orderNumber++;
	    this.orderTime.plusHours(time);
	    this.orderDay = day;
	    this.customer = new Customer(customerName,customerAge);
	    this.customer.setName(customerName);
	}

	// addNewBeverage method (overloaded)
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
	    Beverage beverage = new Coffee(bevName,"Coffee", size,extraShot,extraSyrup);
	    beverages.add(beverage);
	}

	public void addNewBeverage(String bevName, Size size) {
	    Beverage beverage = new Alcohol(bevName,"Alcohol", size ,false);
	    beverages.add(beverage);
	}

	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {
	    Beverage beverage = new Smoothie(bevName,"Somoothie", size, numOfFruits, addProtein);
	    beverages.add(beverage);
	}
	@Override
	public String toString() {
	StringBuilder sb = new StringBuilder();
	sb.append("Order number: " + orderNumber + "\n");
	sb.append("Order time: " + orderTime + "\n");
	sb.append("Order day: " + orderDay + "\n");
	sb.append("Customer: " + customer.toString() + "\n");
	sb.append("Beverages:\n");
	for (Beverage b : beverages) {
	sb.append(b.toString() + "\n");
	}
	return sb.toString();
	}


	// Overridden compareTo method
	@Override
	public int compareTo(Order other) {
	    if (this.orderNumber == other.orderNumber) {
	        return 0;
	    } else if (this.orderNumber > other.orderNumber) {
	        return 1;
	    } else {
	        return -1;
	    }
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public LocalDateTime getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(LocalDateTime orderTime) {
		this.orderTime = orderTime;
	}

	public Day getOrderDay() {
		return orderDay;
	}

	public void setOrderDay(Day orderDay) {
		this.orderDay = orderDay;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Beverage> getBeverages() {
		return beverages;
	}

	public void setBeverages(List<Beverage> beverages) {
		this.beverages = beverages;
	}


    // Overridden isWeekend method
    @Override
    public boolean isWeekend() {
        if (orderDay.equals("Saturday") || orderDay.equals("Sunday")) {
            return true;
        }
        return false;
    }

	@Override
	public Beverage getBeverage(int itemNo) {
		// TODO Auto-generated method stub
		if(itemNo > beverages.size()) {
			return beverages.get(itemNo-1);
		}return null;
	}

	@Override
	public double calcOrderTotal() {
		double bb = 0;
		for(Beverage b: beverages) {
			bb += b.calcPrice();
		}return bb;
	}

	@Override
	public int findNumOfBeveType(Type type) {
		int size = 0;
		for(Beverage b: beverages) {
			if(b.getType() == type.toString()) {
				size++;
			}
		}return size;
	}


	
}