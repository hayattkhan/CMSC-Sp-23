package A2;

import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import A2.Beverage.Day;
import A2.Beverage.Size;
import A2.Beverage.Type;

public class BevShop implements BevShopInterface {
    private int numOfAlcoholDrink;
    private List<Order> orders;

    public BevShop() {
        numOfAlcoholDrink = 0;
        orders = new ArrayList<>();
    }

    @Override
    public boolean isValidTime(int time) {
        return time >= MIN_TIME && time <= MAX_TIME;
    }

    @Override
    public int getMaxNumOfFruits() {
        return MAX_FRUIT;
    }

    @Override
    public int getMinAgeForAlcohol() {
        return MIN_AGE_FOR_ALCOHOL;
    }

    @Override
    public boolean isMaxFruit(int numOfFruits) {
        return numOfFruits > MAX_FRUIT;
    }

    @Override
    public int getMaxOrderForAlcohol() {
        return MAX_ORDER_FOR_ALCOHOL;
    }

    @Override
    public boolean isEligibleForMore() {
        return numOfAlcoholDrink < MAX_ORDER_FOR_ALCOHOL;
    }

    @Override
    public int getNumOfAlcoholDrink() {
        return numOfAlcoholDrink;
    }

    @Override
    public boolean isValidAge(int age) {
        return age >= MIN_AGE_FOR_ALCOHOL;
    }
    @Override
    public void startNewOrder(int time, Day day, String customerName, int customerAge) {
        if (isValidTime(time) && isValidAge(customerAge)) {
            Order order = new Order(time, day, customerName, customerAge);
            orders.add(order);
        } else {
            // throw an exception or print an error message
        }
    }
 
    @Override
    public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
        Order currentOrder = getCurrentOrder();
        if (currentOrder != null) {
            Beverage coffee = new Coffee(bevName, "Cooffee", size, extraShot, extraSyrup);
            currentOrder.addNewBeverage(bevName, size, extraShot, extraSyrup);
            orders.add(currentOrder);
        } else {
            // throw an exception or print an error message
        }
    }
 
    @Override
    public void processAlcoholOrder(String bevName, Size size) {
        Order currentOrder = getCurrentOrder();
        if (currentOrder != null && currentOrder.getCustomer().getAge() >= MIN_AGE_FOR_ALCOHOL && isEligibleForMore()) {
        	currentOrder.addNewBeverage(bevName, size);
            orders.add(currentOrder);
            numOfAlcoholDrink++;
        } else {
            // throw an exception or print an error message
        }
    }
	@Override
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) {
		Order currentOrder = getCurrentOrder();
        if (currentOrder != null && currentOrder.getCustomer().getAge() >= MIN_AGE_FOR_ALCOHOL && isEligibleForMore()) {
        	currentOrder.addNewBeverage(bevName, size, numOfFruits, addProtein);
            orders.add(currentOrder);
            numOfAlcoholDrink++;
        } else {
            // throw an exception or print an error message
        }
	}

	@Override
	public int findOrder(int orderNo) {
		// 
		int c=0;
		for(Order o:orders) {
			if(o.getOrderNumber() == orderNo)
				c++;
		}return c;
	}

	@Override
	public double totalOrderPrice(int orderNo) {
		double c=0;
		for(Order o:orders) {
			if(o.getOrderNumber() == orderNo)
				c += o.calcOrderTotal();
		}return c;
	}

	@Override
	public double totalMonthlySale() {
	// Create a LocalDateTime object for the end of the month
		LocalDateTime endOfMonth = LocalDateTime.of(LocalDate.of(2022, 12, 31), LocalTime.MAX);
		// Initialize total to 0
		double total = 0;
		
		// Loop through all orders
		for (Order order : orders) {
			// If the order time is before the end of the month, add the order total to the total
			if (order.getOrderTime().isBefore(endOfMonth)) {
				total += order.calcOrderTotal();
			}
		}
		
		// Return the total
		return total;
	}


	@Override
	public int totalNumOfMonthlyOrders() {
		LocalDateTime t = LocalDateTime.of(LocalDate.of(2022, 12, 31), LocalTime.MAX);
		int count = 0;
		for (Order o : orders) {
			if (o.getOrderTime().compareTo(t) < 0) {
				count++;
			}
		}
		return count;
	}
	@Override
	public Order getCurrentOrder() {
		// Return the last order in the list of orders
		return orders.get(orders.size() - 1);
	}
	
	@Override
	public Order getOrderAtIndex(int index) {
	    // Check if the given index is valid
	    if (index >= 0 && index < orders.size()) {
	        // Return the order at the given index
	        return orders.get(index);
	    }
	    // Return null if the index is not valid
	    return null;
	}

	@Override
	public void sortOrders() {
	    // Sort the list of orders in ascending order by their order numbers
	    Collections.sort(orders);
	}

}