package A2;

public class Alcohol extends Beverage {
	// instance variable
	private boolean weekendOffer;

	// constructor
	public Alcohol(String name, String type, Size size, boolean weekendOffer) {
	    super(name, type, size);
	    this.weekendOffer = weekendOffer;
	}

	// Overridden calcPrice method
	@Override
	public double calcPrice() {
	    double price = super.getBasePrice()  * super.getSizePrice();
	    if (weekendOffer) {
	        price += 0.60;
	    }
	    return price;
	}

	// Overridden toString method
	@Override
	public String toString() {
	    return "Alcohol [name=" + super.getName() + ", size=" + super.getSize() + ", weekendOffer=" + weekendOffer + ", price=" + calcPrice() + "]";
	}

	// Overridden equals method
	@Override
	public boolean equals(Object obj) {
	    if (this == obj)
	        return true;
	    if (obj == null)
	        return false;
	    if (getClass() != obj.getClass())
	        return false;
	    Alcohol other = (Alcohol) obj;
	    if (weekendOffer != other.weekendOffer)
	        return false;
	    return super.equals(obj);
	}

	// getters and setters
	public boolean isWeekendOffer() {
	    return weekendOffer;
	}

	public void setWeekendOffer(boolean weekendOffer) {
	    this.weekendOffer = weekendOffer;
	}
	}