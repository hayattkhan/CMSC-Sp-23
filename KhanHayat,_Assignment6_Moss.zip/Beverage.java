package A2;

public abstract class Beverage {
	
	public enum Size {
	    SMALL,
	    MEDIUM,
	    LARGE
	}
	
	public enum Type {
	    COFFEE,
	    SMOOTHIE,
	    ALCOHOL
	}

	public enum Day {
	    MONDAY,
	    TUESDAY,
	    WEDNESDAY,
	    THURSDAY,
	    FRIDAY,
	    SATURDAY,
	    SUNDAY
	}
	
	

    // instance variables
    private String name;
    private String type;
    private Size size;
    private final double BASE_PRICE = 2.0;
    private final double SIZE_PRICE = 1.0;

    // constructor
    public Beverage(String name, String type, Size size2) {
        this.name = name;
        this.type = type;
        this.size = size2;
    }

    
    // abstract calcPrice method
    public abstract double calcPrice();

    // Overridden toString method
    @Override
    public String toString() {
        return "Beverage [name=" + name + ", size=" + size + "]";
    }

    // Overridden equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Beverage other = (Beverage) obj;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (size != other.size)
            return false;
        if (type != other.type)
            return false;
        return true;
    }

    // getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public double getBasePrice() {
        return BASE_PRICE;
    }

    public double getSizePrice() {
        return SIZE_PRICE;
    }
}
