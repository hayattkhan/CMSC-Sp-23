package A2;

public class Smoothie extends Beverage {
	// additional instance variables
	private int numOfFruits;
	private boolean proteinAdded;
	private final double PROTEIN_PRICE = 1.5;
	private final double FRUIT_PRICE = 0.5;
	// parametrized constructor
	public Smoothie(String name, String type, Size size, int numOfFruits, boolean addProtein) {
	    super(name, type, size);
	    this.numOfFruits = numOfFruits;
	    this.proteinAdded = addProtein;
	}

	// Overridden calcPrice method
	@Override
	public double calcPrice() {
	    // calculate the price of the smoothie based on its size, number of fruits, and whether or not protein is added
	    double price = super.getBasePrice() * super.getSizePrice();
	    if (proteinAdded) {
	        price += PROTEIN_PRICE;
	    }
	    price += numOfFruits * FRUIT_PRICE;
	    return price;
	}

	// Overridden toString method
	@Override
	public String toString() {
	    return "Smoothie [name=" + super.getName() + ", size=" + super.getSize() + ", proteinAdded=" + proteinAdded + ", numOfFruits=" + numOfFruits + ", price=" + calcPrice() + "]";
	}
	// Overridden equals method
	@Override
	public boolean equals(Object obj) {
	    if (this == obj)
	        return true;
	    if (obj == null)
	        return false;
	    if (getClass() != obj.getClass())
	        return false;
	    Smoothie other = (Smoothie) obj;
	    if (numOfFruits != other.numOfFruits)
	        return false;
	    if (proteinAdded != other.proteinAdded)
	        return false;
	    return super.equals(obj);
	}

	// getters and setters
	public int getNumOfFruits() {
	    return numOfFruits;
	}

	public void setNumOfFruits(int numOfFruits) {
	    this.numOfFruits = numOfFruits;
	}

	public boolean isProteinAdded() {
	    return proteinAdded;
	}

	public void setProteinAdded(boolean proteinAdded) {
	    this.proteinAdded = proteinAdded;
	}
}