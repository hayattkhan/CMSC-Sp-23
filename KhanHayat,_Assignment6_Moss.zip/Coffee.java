package A2;


public class Coffee extends Beverage {
    // instance variables
    private boolean extraShot;
    private boolean extraSyrup;

    // constants
    private final double EXTRA_SHOT_PRICE = 0.50;
    private final double EXTRA_SYRUP_PRICE = 0.50;

    // parametrized constructor
    public Coffee(String name, String type, Size size, boolean extraShot, boolean extraSyrup) {
        super(name, type, size);
        this.extraShot = extraShot;
        this.extraSyrup = extraSyrup;
    }

    // Overridden calcPrice method
    @Override
    public double calcPrice() {
        double price = super.getBasePrice();

        // add size price if necessary
        if (super.getSize().LARGE == Size.LARGE) {
            price += super.getSizePrice();
        }

        // add extra shot price if necessary
        if (this.extraShot) {
            price += EXTRA_SHOT_PRICE;
        }

        // add extra syrup price if necessary
        if (this.extraSyrup) {
            price += EXTRA_SYRUP_PRICE;
        }

        return price;
    }

    // Overridden toString method
    @Override
    public String toString() {
        return "Coffee [name=" + super.getName() + ", size=" + super.getSize() + ", extraShot=" + extraShot + ", extraSyrup=" + extraSyrup + ", price=" + calcPrice() + "]";
    }


    // Overridden equals method
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Coffee other = (Coffee) obj;
        if (extraShot != other.extraShot)
            return false;
        if (extraSyrup != other.extraSyrup)
            return false;
        return true;
    }

    // getters and setters
    public boolean isExtraShot() {
        return extraShot;
    }

    public void setExtraShot(boolean extraShot) {
        this.extraShot = extraShot;
    }

    public boolean isExtraSyrup() {
        return extraSyrup;
    }

    public void setExtraSyrup(boolean extraSyrup) {
        this.extraSyrup = extraSyrup;
    }
}
