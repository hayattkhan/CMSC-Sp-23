import java.util.Scanner;

public class MovieDriver {

	public static void main(String[] args) 
	{
		Scanner HP = new Scanner(System.in); //scanner to take in user's input
		String letter = "y";
		while(letter.equalsIgnoreCase("Y"))  //to take in multiple movie names
		{
			
			System.out.println("Enter the name of the movie : ");
			String title = HP.nextLine();
			
			
			System.out.println("Enter the rating of the movie : ");
			String rating = HP.next();
			
			
			System.out.println("Enter the number of tickets sold for this movie : ");
			int numerOfTickets = HP.nextInt();
			
			
			Movie name = new Movie(title,rating,numerOfTickets); //to create a new object called name
			System.out.println(name.toString());
			System.out.println("Do you want to enter another ?(y or n)");
			letter = HP.next();
			
			HP.nextLine(); //to read and discard the line feed
			
		}
	System.out.println("Goodbye");
	}
} 
