/*
 * Class: CMSC203-30378
 * Instructor: Prof. Khandan Monshi
 * Description: comments are provided below
 * Due: 04/05/2023
* Platform/compiler:eclipse
 * I pledge that I have completed the programming
* assignment independently. I have not copied the code
* from a student or any source. I have not given my code
* to any student.
   Print your Name here: Hayatullah Khan
*/
package a4;

public class Plot {
	  // Instance variables to represent the x and y coordinates of the upper left corner of the location,
	  // and depth and width to represent the vertical and horizontal extents of the plot.
	  private int x, y, depth, width;

	  // Constructor to initialize the instance variables with the given values
	  public Plot(int x, int y, int depth, int width) {
	    this.x = x;
	    this.y = y;
	    this.depth = depth;
	    this.width = width;
	  }

	  // Getter methods to return the values of the instance variables
	  public int getX() {
	    return x;
	  }

	  public int getY() {
	    return y;
	  }

	  public int getDepth() {
	    return depth;
	  }

	  public int getWidth() {
	    return width;
	  }

	  // Setter methods to set the values of the instance variables
	  public void setX(int x) {
	    this.x = x;
	  }

	  public void setY(int y) {
	    this.y = y;
	  }

	  public void setDepth(int depth) {
	    this.depth = depth;
	  }

	  public void setWidth(int width) {
	    this.width = width;
	  }

	  // Method named overlaps that takes a Plot instance and determines if it is overlapped by the current plot
	  public boolean overlaps(Plot other) {
	    // Calculate the coordinates of the edges of the current plot
	    int thisLeft = this.x;
	    int thisTop = this.y;
	    int thisRight = this.x + this.width;
	    int thisBottom = this.y + this.depth;

	    // Calculate the coordinates of the edges of the other plot
	    int otherLeft = other.x;
	    int otherTop = other.y;
	    int otherRight = other.x + other.width;
	    int otherBottom = other.y + other.depth;

	    // Check if the plots overlap
	    return (thisLeft < otherRight && thisRight > otherLeft && thisTop < otherBottom && thisBottom > otherTop);
	  }

	  public boolean encompasses(Plot other) {
		  // Calculate the coordinates of the edges of the current plot
		  int thisLeft = this.x;
		  int thisTop = this.y;
		  int thisRight = this.x + this.width;
		  int thisBottom = this.y + this.depth;

		  // Calculate the coordinates of the edges of the other plot
		  int otherLeft = other.x;
		  int otherTop = other.y;
		  int otherRight = other.x + other.width;
		  int otherBottom = other.y + other.depth;

		  // Check if the other plot is completely contained within the current plot
		  return (thisLeft <= otherLeft && thisTop <= otherTop && thisRight >= otherRight && thisBottom >= otherBottom);
		}

	  public String toString() {
		  return x + "," + y + "," + width + "," + depth;
		}


	  public static void main(String []args) {
		  System.out.println("Hayat khan");
		  System.out.println("Plot class main function running");
	  }

}
