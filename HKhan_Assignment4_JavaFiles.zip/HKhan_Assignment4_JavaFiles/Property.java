/*
 * Class: CMSC203-30378
 * Instructor: Prof. Khandan Monshi
 * Description: comments are provided below
 * Due: 04/05/2023
* Platform/compiler:eclipse
 * I pledge that I have completed the programming
* assignment independently. I have not copied the code
* from a student or any source. I have not given my code
* to any student.
   Print your Name here: Hayatullah Khan
*/
package a4;

public class Property {
	  // Instance variables for property name, city, rental amount, owner, and plot
	  private String name;
	  private String city;
	  private double rentalAmount;
	  private String owner;
	  private Plot plot;

	  // Constructors
	  public Property() {
	    // Default constructor
	  }

	  public Property(String name, String city, double rentalAmount, String owner, Plot plot) {
	    this.name = name;
	    this.city = city;
	    this.rentalAmount = rentalAmount;
	    this.owner = owner;
	    this.plot = plot;
	  }

	  // Getter and setter methods
	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  public String getCity() {
	    return city;
	  }

	  public void setCity(String city) {
	    this.city = city;
	  }

	  public double getRentalAmount() {
	    return rentalAmount;
	  }

	  public void setRentalAmount(double rentalAmount) {
	    this.rentalAmount = rentalAmount;
	  }

	  public String getOwner() {
	    return owner;
	  }

	  public void setOwner(String owner) {
	    this.owner = owner;
	  }

	  public Plot getPlot() {
	    return plot;
	  }

	  public void setPlot(Plot plot) {
	    this.plot = plot;
	  }

	  // toString method to represent a Property instance
	  public String toString() {
	    return name + "," + city + "," + owner + "," + rentalAmount;
	  }

	public String getPropertyName() {
		// TODO Auto-generated method stub
		return null;
	}
	public static void main(String []args) {
		  System.out.println("Hayat khan");
		  System.out.println("Property class main function running");
	}
	}
