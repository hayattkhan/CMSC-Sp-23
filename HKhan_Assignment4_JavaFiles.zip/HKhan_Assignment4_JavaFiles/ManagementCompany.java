/*
 * Class: CMSC203-30378
 * Instructor: Prof. Khandan Monshi
 * Description: comments are provided below
 * Due: 04/05/2023
* Platform/compiler:eclipse
 * I pledge that I have completed the programming
* assignment independently. I have not copied the code
* from a student or any source. I have not given my code
* to any student.
   Print your Name here: Hayatullah Khan
*/
package a4;

public class ManagementCompany {
	  // Constant class variables
	  public static final int MAX_PROPERTY = 5; // The max number of properties a management company can have
	  public static final int MGMT_WIDTH = 10; // The width of the management company's plot
	  public static final int MGMT_DEPTH = 10; // The depth of the management company's plot

	  // Instance variables for ManagementCompany name, Tax Id, management fee percentage
	  private String name;
	  private String taxId;
	  private double managementFeePercentage;

	  // Instance array variable to store the properties of a management company
	  private Property[] properties;

	  // Instance variable to store the plot of the management company
	  private Plot plot;

	  // Instance variable to store the current number of properties of a management company
	  private int numberOfProperties;

	  // Constructors
	  public ManagementCompany() {
	    // Default constructor
	    this.name = "";
	    this.taxId = "";
	    this.managementFeePercentage = 0.0;
	    this.properties = new Property[MAX_PROPERTY];
	    this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
	    this.numberOfProperties = 0;
	  }

	  public ManagementCompany(String name, String taxId, double managementFeePercentage, int x, int y, int width, int depth) {
	    this.name = name;
	    this.taxId = taxId;
	    this.managementFeePercentage = managementFeePercentage;
	    this.properties = new Property[MAX_PROPERTY];
	    this.plot = new Plot(x, y, width, depth);
	    this.numberOfProperties = 0;
	  }

	  // Getter and setter methods
	  public String getName() {
	    return name;
	  }

	  public void setName(String name) {
	    this.name = name;
	  }

	  public String getTaxId() {
	    return taxId;
	  }

	  public void setTaxId(String taxId) {
	    this.taxId = taxId;
	  }
	  public void setManagementFeePercentage(double managementFeePercentage) {
		    this.managementFeePercentage = managementFeePercentage;
	  }

	  public int addProperty(Property property) {
		    if (property == null) {
		        return -2;
		    }
		    if (properties.length == MAX_PROPERTY) {
		        return -1;
		    }
		    if (!plot.encompasses(property.getPlot())) {
		        return -3;
		    }
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] != null && properties[i].getPlot().overlaps(property.getPlot())) {
		            return -4;
		        }
		    }
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] == null) {
		            properties[i] = property;
		            return i;
		        }
		    }
		    return -1;
		}
	  public double getTotalRent() {
		    double totalRent = 0;
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] != null) {
		            totalRent += properties[i].getRentalAmount();
		        }
		    }
		    return totalRent;
		}

	  public Property getHighestRentProperty() {
		    Property highestRentProperty = null;
		    double highestRent = 0;
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] != null && properties[i].getRentalAmount() > highestRent) {
		            highestRentProperty = properties[i];
		            highestRent = properties[i].getRentalAmount();
		        }
		    }
		    return highestRentProperty;
		}

		public void removeLastProperty() {
		    for (int i = properties.length - 1; i >= 0; i--) {
		        if (properties[i] != null) {
		            properties[i] = null;
		            return;
		        }
		    }
		}

		public boolean isPropertiesFull() {
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] == null) {
		            return false;
		        }
		    }
		    return true;
		}

		public int getPropertiesCount() {
		    int count = 0;
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] != null) {
		            count++;
		        }
		    }
		    return count;
		}

		public boolean isManagementFeeValid() {
		    return managementFeePercentage >= 0 && managementFeePercentage <= 100;
		}

		@Override
		public String toString() {
		    StringBuilder sb = new StringBuilder();
		    sb.append("List of the properties for ").append(name).append(", taxID: ").append(getTaxId()).append("\n");
		    sb.append("______________________________________________________\n");
		    for (int i = 0; i < properties.length; i++) {
		        if (properties[i] != null) {
		            sb.append(properties[i].toString()).append("\n");
		        }
		    }
		    sb.append("______________________________________________________\n");
		    sb.append(" total management Fee: ").append(this.managementFeePercentage).append("\n");
		    return sb.toString();
		}

		public static void main(String []args) {
			  System.out.println("Hayat khan");
			  System.out.println("ManagementCompany class main function running");
		}
}
