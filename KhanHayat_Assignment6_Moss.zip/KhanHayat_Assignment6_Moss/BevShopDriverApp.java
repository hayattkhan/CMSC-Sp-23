/*
 * Class: CMSC203 
 * Instructor: Prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public class BevShopDriverApp 
{
	public static void main(String[] args)
	{
		BevShop drinkShop = new BevShop();
		
		//Order 1
		System.out.println("Starting a new order!");
		drinkShop.startNewOrder(12, Day.SUNDAY, "Jeff", 15);
		System.out.println("Total on the Order: " + drinkShop.getCurrentOrder().calcOrderTotal()); // 0.0
		System.out.println("Name: " + drinkShop.getCurrentOrder().getCustomer().getName());
		System.out.println("Age: " + drinkShop.getCurrentOrder().getCustomer().getAge());
		if(drinkShop.isValidAge(15))
		{
			System.out.println("You are atleast 21, you are allowed to get Alcohol.");
		}
		else
		{
			System.out.println("You are not allowed to get Alcohol.");
		}
		System.out.println("-Add Chai Latte, Mango Smoothie, and Bud Light to order");
		drinkShop.processCoffeeOrder("Chai Latte", Size.MEDIUM, false, false);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.MEDIUM, 3, false);
		drinkShop.processAlcoholOrder("Bud Light", Size.MEDIUM);
		System.out.println("Order details: " + drinkShop.getCurrentOrder());
		System.out.println("Final order total price: " + drinkShop.totalOrderPrice(drinkShop.getCurrentOrder().getOrderNo()));

		
		
		//Order 2
		System.out.println("\nStarting a new order!");
		drinkShop.startNewOrder(22, Day.SUNDAY, "Bob", 25);
		System.out.println("Total on the Order: " + drinkShop.getCurrentOrder().calcOrderTotal()); // 0.0
		System.out.println("Name: " + drinkShop.getCurrentOrder().getCustomer().getName());
		System.out.println("Age: " + drinkShop.getCurrentOrder().getCustomer().getAge());
		if(drinkShop.isValidAge(25))
		{
			System.out.println("You are atleast 21, you are allowed to get Alcohol.");
		}
		else
		{
			System.out.println("You are not allowed to get Alcohol.");
		}
		System.out.println("-Add Bud Light, Beer, Vodka, and Wine to order");
		drinkShop.processAlcoholOrder("Bud Light", Size.MEDIUM);
		drinkShop.processAlcoholOrder("Beer", Size.SMALL);
		drinkShop.processAlcoholOrder("Vodka", Size.LARGE);
		drinkShop.processAlcoholOrder("Wine", Size.MEDIUM);
		System.out.println("Order details: " + drinkShop.getCurrentOrder());
		System.out.println("Final order total price: " + drinkShop.totalOrderPrice(drinkShop.getCurrentOrder().getOrderNo()));
		
		
		
		//Order 3
		System.out.println("\nStarting a new order!");
		drinkShop.startNewOrder(16, Day.MONDAY, "Bob", 30);
		System.out.println("Total on the Order: " + drinkShop.getCurrentOrder().calcOrderTotal()); // 0.0
		System.out.println("Name: " + drinkShop.getCurrentOrder().getCustomer().getName());
		System.out.println("Age: " + drinkShop.getCurrentOrder().getCustomer().getAge());
		if(drinkShop.isValidAge(30))
		{
			System.out.println("You are atleast 21, you are allowed to get Alcohol.");
		}
		else
		{
			System.out.println("You are not allowed to get Alcohol.");
		}
		System.out.println("-Add Bud Light and Vodka to order");
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		drinkShop.processAlcoholOrder("Vodka", Size.LARGE);
		System.out.println("Order details: " + drinkShop.getCurrentOrder());
		System.out.println("Final order total price: " + drinkShop.totalOrderPrice(drinkShop.getCurrentOrder().getOrderNo()));


		
		//ee
		System.out.println();
		
		drinkShop.sortOrders();
		
		System.out.println(drinkShop);
		
		System.out.print("We had a total of " + drinkShop.totalNumOfMonthlyOrders() + " orders."
				+ "\nMonthly total is: $" + drinkShop.totalMonthlySale());
	}
	
}
