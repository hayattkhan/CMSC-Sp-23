/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 12/11/2022
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public class Coffee extends Beverage
{
	private boolean extraShot;
	private boolean extraSyrup;
	
	//constant additional prices;
	private final double ADDITIONAL_SHOT_COST = .50;
	private final double ADDITIONAL_SYRUP_COST = .50;

	public Coffee(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		super(bevName, Type.COFFEE, size);
		this.extraShot = extraShot;
		this.extraSyrup = extraSyrup;
	}
	
	public String toString()
	{
		return super.toString() + "," + extraShot + "," + extraSyrup + "," + calcPrice();
	}
	
	public boolean equals(Object anotherBev) 
	{
		Coffee tempCoffee = (Coffee) anotherBev;
		
		if(super.equals(tempCoffee) && 
				this.extraShot == tempCoffee.extraShot && 
				this.extraSyrup == tempCoffee.extraSyrup && 
				this.calcPrice() == tempCoffee.calcPrice()) //ask about this
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	@Override
	public double calcPrice() 
	{
		double coffeePrice;
		coffeePrice = super.addSizePrice();
		
		if(extraShot)
		{
			coffeePrice += ADDITIONAL_SHOT_COST;
		}
		
		if(extraSyrup)
		{
			coffeePrice += ADDITIONAL_SYRUP_COST;
		}

		return coffeePrice;
	}
	
	//getters
	public boolean getExtraShot()
	{
		return extraShot;
	}
	public boolean getExtraSyrup()
	{
		return extraSyrup;
	}
}
