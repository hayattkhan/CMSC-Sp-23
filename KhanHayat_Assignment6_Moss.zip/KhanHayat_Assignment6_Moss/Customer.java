/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public class Customer 
{
	private int age;
	private String name;
	
	//A parametrized constructor 
	public Customer(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	//A Copy constructor  
	public Customer(Customer c)
	{
		this.name = c.name;
		this.age = c.age;
	}
	
	//getters
	public int getAge()
	{
		return age;
	}
	public String getName()
	{
		return name;
	}
	
	//setters
	public void setAge(int age)
	{
		this.age = age;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	@Override
	public String toString()
	{
		return name + "," + age;
	}

}
