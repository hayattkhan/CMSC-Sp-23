/*
 * Class: CMSC203 
 * Instructor: Prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BevShopTestStudent 
{
	BevShop drinkShop;

	@BeforeEach
	void setUp() throws Exception 
	{
		drinkShop = new BevShop();
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		drinkShop = null;
	}

	@Test
	void testIsValidTime() 
	{
		assertTrue(drinkShop.isValidTime(9));
		assertTrue(drinkShop.isValidTime(21));
		assertTrue(drinkShop.isValidTime(10));
		
		assertFalse(drinkShop.isValidTime(1));
		assertFalse(drinkShop.isValidTime(7));
		assertFalse(drinkShop.isValidTime(24));
	}
	
	@Test
	void testGetMaxNumOfFruits() 
	{
		assertEquals(5, drinkShop.getMaxNumOfFruits());
	}
	
	@Test
	void testGetMinAgeForAlcohol()
	{
		assertEquals(21, drinkShop.getMinAgeForAlcohol());
	}
	
	@Test
	void testIsMaxFruit() 
	{
		assertFalse(drinkShop.isMaxFruit(4));
		assertFalse(drinkShop.isMaxFruit(0));
		assertFalse(drinkShop.isMaxFruit(3));
		
		assertTrue(drinkShop.isMaxFruit(56));
		assertTrue(drinkShop.isMaxFruit(33));
		assertTrue(drinkShop.isMaxFruit(100));
	}
	
	@Test
	void testGetMaxOrderForAlcohol() 
	{
		assertEquals(3, drinkShop.getMaxOrderForAlcohol());
	}
	
	@Test
	void testIsEligibleForMore() 
	{
		drinkShop.startNewOrder(8, Day.MONDAY, "Bob", 25);
		
		drinkShop.processAlcoholOrder("Corona", Size.LARGE);
		assertTrue(drinkShop.isEligibleForMore());
		
		drinkShop.processAlcoholOrder("Beer", Size.SMALL);
		assertTrue(drinkShop.isEligibleForMore());
		
		drinkShop.processAlcoholOrder("Bud Light", Size.MEDIUM);
		assertFalse(drinkShop.isEligibleForMore());
	}
	
	@Test
	void testGetNumOfAlcoholDrink() 
	{
		drinkShop.startNewOrder(8, Day.MONDAY, "Bob", 25);
		drinkShop.processAlcoholOrder("Corona", Size.LARGE);
		assertEquals(1, drinkShop.getNumOfAlcoholDrink());
		
		drinkShop.processAlcoholOrder("Beer", Size.SMALL);
		drinkShop.processAlcoholOrder("Bud Light", Size.MEDIUM);
		assertEquals(3, drinkShop.getNumOfAlcoholDrink());
	}
	
	@Test
	void testIsValidAge()
	{
		assertFalse(drinkShop.isValidAge(15));
		assertFalse(drinkShop.isValidAge(18));
		assertFalse(drinkShop.isValidAge(20));
		
		assertTrue(drinkShop.isValidAge(21));
		assertTrue(drinkShop.isValidAge(35));
		assertTrue(drinkShop.isValidAge(22));
	}
	
	@Test
	void testStartNewOrder()
	{
		drinkShop.startNewOrder(9, Day.MONDAY, "Bob", 25);

		assertEquals(9, drinkShop.getCurrentOrder().getOrderTime());
		assertEquals(Day.MONDAY, drinkShop.getCurrentOrder().getOrderDay());
		assertEquals("Bob", drinkShop.getCurrentOrder().getCustomer().getName());
		assertEquals(25, drinkShop.getCurrentOrder().getCustomer().getAge());
	}
	
	@Test
	void testProcessCoffeeOrder()
	{
		drinkShop.startNewOrder(9, Day.MONDAY, "Bob", 25);
		
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, true);
		
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 1);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getBevName().equals("Chai Latte"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getSize().equals(Size.LARGE));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getType().equals(Type.COFFEE));
		assertTrue(drinkShop.isEligibleForMore());
		
		drinkShop.processCoffeeOrder("Black Tea", Size.SMALL, false, true);
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 2);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getBevName().equals("Black Tea"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getSize().equals(Size.SMALL));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getType().equals(Type.COFFEE));
		
		assertEquals(1,drinkShop.totalNumOfMonthlyOrders());
	}
	
	@Test
	void testProcessAlcoholOrder()
	{
		drinkShop.startNewOrder(9, Day.MONDAY, "Bob", 25);
		
		drinkShop.processAlcoholOrder("Corona", Size.LARGE);
		
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 1);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getBevName().equals("Corona"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getSize().equals(Size.LARGE));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getType().equals(Type.ALCOHOL));	
		assertTrue(drinkShop.isEligibleForMore());
		
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 2);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getBevName().equals("Bud Light"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getSize().equals(Size.SMALL));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getType().equals(Type.ALCOHOL));
		
		assertEquals(1,drinkShop.totalNumOfMonthlyOrders());
	}
	
	@Test
	void testProcessSmoothieOrder()
	{
		drinkShop.startNewOrder(9, Day.MONDAY, "Bob", 25);
		
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
		
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 1);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getBevName().equals("Mango Smoothie"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getSize().equals(Size.LARGE));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(0).getType().equals(Type.SMOOTHIE));
		assertTrue(drinkShop.isEligibleForMore());
		
		drinkShop.processSmoothieOrder("Banana Smoothie", Size.MEDIUM, 4, true);
		assertTrue(drinkShop.getCurrentOrder().getTotalItems() == 2);
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getBevName().equals("Banana Smoothie"));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getSize().equals(Size.MEDIUM));
		assertTrue(drinkShop.getCurrentOrder().getBeverage(1).getType().equals(Type.SMOOTHIE));
		
		assertEquals(1,drinkShop.totalNumOfMonthlyOrders());
	}
	
	@Test
	public void testTotalOrderPrice()
	{
	 	int orderNumber1;
	 	int orderNumber2;
		
	 	drinkShop.startNewOrder(8, Day.TUESDAY, "Jake", 18);
	 	drinkShop.processCoffeeOrder("Chai Latte", Size.SMALL, true, false); 
	 	drinkShop.processCoffeeOrder("Cappuccino", Size.LARGE, false, false);
	 	drinkShop.processCoffeeOrder("Black Tea", Size.LARGE,true, true);
	 	orderNumber1 = drinkShop.getCurrentOrder().getOrderNo();
	 	assertEquals(11.5,drinkShop.totalOrderPrice(orderNumber1),.01);
		
		drinkShop.startNewOrder(12, Day.SATURDAY, "Bob", 31);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.SMALL, 2, false);
		orderNumber2 = drinkShop.getCurrentOrder().getOrderNo();
		assertEquals(3.0,drinkShop.totalOrderPrice(orderNumber2),.01 );
		
	}
	
	@Test
	public void testTotalMonthlySale()
	{
		drinkShop.startNewOrder(8, Day.TUESDAY,"Jake", 18);
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, false); 
		drinkShop.processCoffeeOrder("Black Tea", Size.LARGE, false, false);
		drinkShop.processCoffeeOrder("Cappuccino", Size.LARGE,true, true);
		System.out.println(drinkShop.totalMonthlySale());
		drinkShop.startNewOrder(11, Day.SUNDAY,"Bob", 25);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.SMALL, 1, false);
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		System.out.println(drinkShop.totalMonthlySale());
		drinkShop.startNewOrder(12, Day.SUNDAY,"Tom", 52);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
		drinkShop.processCoffeeOrder("Chai Latte", Size.SMALL,false, false);		 
		System.out.println(drinkShop.totalMonthlySale());
	 
		assertEquals(28.1, drinkShop.totalMonthlySale(), .01 );
 
	}
	
	@Test
	public void testTotalNumOfMonthlyOrders()
	{
		drinkShop.startNewOrder(8, Day.TUESDAY,"Jake", 18);
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, false); 
		drinkShop.processCoffeeOrder("Black Tea", Size.LARGE, false, false);
		drinkShop.processCoffeeOrder("Cappuccino", Size.LARGE,true, true);
	
		drinkShop.startNewOrder(11, Day.SUNDAY,"Bob", 25);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.SMALL, 1, false);
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		
		drinkShop.startNewOrder(12, Day.SUNDAY,"Tom", 52);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
		drinkShop.processCoffeeOrder("Chai Latte", Size.SMALL,false, false);		 

	 
		assertEquals(3, drinkShop.totalNumOfMonthlyOrders(), 0.0);
 
	}
	
	@Test
	public void testGetCurrentOrder()
	{
		drinkShop.startNewOrder(8, Day.TUESDAY,"Jake", 18);
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, false); 
		drinkShop.processCoffeeOrder("Black Tea", Size.LARGE, false, false);
		drinkShop.processCoffeeOrder("Cappuccino", Size.LARGE,true, true);
	
		drinkShop.startNewOrder(11, Day.SUNDAY,"Bob", 25);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.SMALL, 1, false);
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		
		drinkShop.startNewOrder(12, Day.SUNDAY,"Tom", 52);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
		drinkShop.processCoffeeOrder("Chai Latte", Size.SMALL,false, false);		 

	 
		assertEquals(drinkShop.getOrderAtIndex(2), drinkShop.getCurrentOrder());
		
		//System.out.println(drinkShop.getCurrentOrder());
 
	}
	
	@Test
	public void testGetOrderAtIndex()
	{
		drinkShop.startNewOrder(8, Day.TUESDAY,"Jake", 18);
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, false); 
		drinkShop.processCoffeeOrder("Black Tea", Size.LARGE, false, false);
		drinkShop.processCoffeeOrder("Cappuccino", Size.LARGE,true, true);
	
		drinkShop.startNewOrder(11, Day.SUNDAY,"Bob", 25);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.SMALL, 1, false);
		drinkShop.processAlcoholOrder("Bud Light", Size.SMALL);
		
		drinkShop.startNewOrder(12, Day.SUNDAY,"Tom", 52);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
		drinkShop.processCoffeeOrder("Chai Latte", Size.SMALL,false, false);		 

	 
		assertEquals(drinkShop.getCurrentOrder(), drinkShop.getOrderAtIndex(2));
	}
	
	@Test
	public void testSortOrders()
	{
		drinkShop.startNewOrder(8, Day.TUESDAY, "Bob", 18);
		drinkShop.startNewOrder(11, Day.SUNDAY, "Tom", 25);
		drinkShop.startNewOrder(12, Day.SUNDAY, "Jake", 52);
		
		drinkShop.sortOrders();
		assertTrue(drinkShop.getOrderAtIndex(0).getOrderNo() < drinkShop.getOrderAtIndex(1).getOrderNo());	 
		assertTrue(drinkShop.getOrderAtIndex(1).getOrderNo() < drinkShop.getOrderAtIndex(2).getOrderNo());
		
	}
	
	@Test
	public void testToString() {
		
		drinkShop.startNewOrder(8, Day.TUESDAY,"Jake", 18);
		drinkShop.processCoffeeOrder("Chai Latte", Size.LARGE, true, false); 
		drinkShop.processCoffeeOrder("Black Tea", Size.LARGE, false, false);
		 
	
		drinkShop.startNewOrder(12, Day.SUNDAY,"Tom", 52);
		drinkShop.processSmoothieOrder("Mango Smoothie", Size.LARGE, 4, true);
			  
		 
		assertTrue(drinkShop.toString().contains( String.valueOf(drinkShop.getOrderAtIndex(0).getOrderNo()) ));
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(0).getCustomer().getName()) );
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(0).getBeverage(0).getSize().toString()) )  ;
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(0).getBeverage(0).getBevName()) );
		
	 	
		assertTrue(drinkShop.toString().contains( String.valueOf(drinkShop.getOrderAtIndex(1).getOrderNo()) ));
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(1).getCustomer().getName()) );
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(1).getBeverage(0).getSize().toString()) )  ;
		assertTrue(drinkShop.toString().contains(drinkShop.getOrderAtIndex(1).getBeverage(0).getBevName()) );
		
		assertTrue(drinkShop.toString().contains( String.valueOf(drinkShop.totalMonthlySale())));
		
		//System.out.println(drinkShop.toString());
		
		assertEquals("Total monthly sales: 16.0\n[" + drinkShop.getOrderAtIndex(0).getOrderNo() 
				+ ",8,TUESDAY,Jake,18,[Chai Latte,LARGE,true,false,4.5, Black Tea,LARGE,false,false,4.0], "
				+ drinkShop.getOrderAtIndex(1).getOrderNo() + ",12,SUNDAY,Tom,52,[Mango Smoothie,LARGE,true,4,7.5]]" ,drinkShop.toString());
	}
}
