/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import java.util.ArrayList;

public class BevShop implements BevShopInterface
{
	private int numberOfAlcoholDrinks;
	private ArrayList<Order> instanceList;
	
	//default constructor
	public BevShop()
	{
		instanceList = new ArrayList<Order>();
	}
	
	@Override
	public boolean isValidTime(int time)
	{
		return (time < MAX_TIME && time > MIN_TIME);
	}
	@Override
	public int getMaxNumOfFruits() 
	{
		return MAX_FRUIT;
	}
	@Override
	public int getMinAgeForAlcohol() 
	{
		return MIN_AGE_FOR_ALCOHOL;
	}
	@Override
	public boolean isMaxFruit(int numOfFruits)
	{
		return (numOfFruits > MAX_FRUIT);
	}
	@Override
	public int getMaxOrderForAlcohol() 
	{
		return MAX_ORDER_FOR_ALCOHOL;
	}
	@Override
	public boolean isEligibleForMore() 
	{
		return(getNumOfAlcoholDrink() < MAX_ORDER_FOR_ALCOHOL);
	}
	@Override
	public int getNumOfAlcoholDrink() 
	{
		int numberOfAlcohols = getCurrentOrder().findNumOfBeveType(Type.ALCOHOL);
		return numberOfAlcohols;
	}
	@Override
	public boolean isValidAge(int age) 
	{
		return (age >= MIN_AGE_FOR_ALCOHOL);
	}
	@Override
	public void startNewOrder(int time, Day day, String customerName, int customerAge) 
	{
		Order newOrder = new Order(time, day, new Customer(customerName, customerAge));
		instanceList.add(newOrder);
		numberOfAlcoholDrinks = 0;
	}
	@Override
	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		//instanceList.get(instanceList.size() - 1).addNewBeverage(bevName, size, extraShot, extraSyrup);

		getCurrentOrder().addNewBeverage(bevName, size, extraShot, extraSyrup);
	}
	@Override
	public void processAlcoholOrder(String bevName, Size size) 
	{
		if(isValidAge(getCurrentOrder().getCustomer().getAge()))
			{
				if(isEligibleForMore())
					{
						getCurrentOrder().addNewBeverage(bevName, size);
					}
			}
			
		else
		{
			System.out.println("You're NOT 21!!!!");
		}
	}
	@Override
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) 
	{
		getCurrentOrder().addNewBeverage(bevName, size, numOfFruits, addProtein);
	}
	@Override
	public int findOrder(int orderNo) 
	{
		for(int index = 0; index < instanceList.size(); index++)
		{
			if(orderNo == instanceList.get(index).getOrderNo())
			{
				return index;
			}
		}
		
		return -1;
	}
	@Override
	public double totalOrderPrice(int orderNo) 
	{
		double total;
		total = instanceList.get(findOrder(orderNo)).calcOrderTotal();
		return total;
	}	
	@Override
	public double totalMonthlySale() 
	{
		double monthTotal = 0.0;
		
		for(int index = 0; index < instanceList.size(); index++) 
		{
			monthTotal += instanceList.get(index).calcOrderTotal();
		}
		
		return monthTotal;
	}
	@Override
	public int totalNumOfMonthlyOrders() 
	{
		return instanceList.size();
	}
	@Override
	public Order getCurrentOrder() 
	{
		return getOrderAtIndex(instanceList.size() - 1);
	}
	@Override
	public Order getOrderAtIndex(int index) 
	{
		return instanceList.get(index);
	}
	@Override
	public void sortOrders() 
	{
		for(int index1 = 0; index1 < (instanceList.size() - 1); index1++) 
		{
			int index3 = index1;
			
			for(int index2 = index1+1; index2 < instanceList.size(); index2++) 
			{
				if(instanceList.get(index2).compareTo(instanceList.get(index3)) == -1)
				{
					index3 = index2;
				}
			}
			
			Order twoSecondUSe = instanceList.get(index3);
			instanceList.set(index3, instanceList.get(index1));
			instanceList.set(index1, twoSecondUSe);
		}
	}
	
	@Override
	public String toString()
	{
		//"Total monthly sales: " + totalMonthlySale() + "\n" + this.instanceList
		return "Total monthly sales: " + totalMonthlySale() + "\n" + this.instanceList;
	}
}
