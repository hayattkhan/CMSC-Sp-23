/*
 * Class: CMSC203 
 * Instructor: Prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public class Smoothie extends Beverage
{
	private int numberOfFruits;
	private boolean isProteinPowderAddedToBeverage;
	
	private final double COST_OF_PROTIEN = 1.50; //$1.50
	private final double COST_OF_ADDITIONAL_FRUIT = 0.50; //$0.50
	
	public Smoothie(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		super(bevName, Type.SMOOTHIE, size);
		this.numberOfFruits = numOfFruits;
		this.isProteinPowderAddedToBeverage = addProtein;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + "," + isProteinPowderAddedToBeverage + "," + numberOfFruits + "," + this.calcPrice();
	}
	
	@Override
	public boolean equals(Object anotherBev)
	{
		Smoothie tempSmoothie = (Smoothie) anotherBev;
		
		if(super.equals(tempSmoothie) && 
				this.calcPrice() == tempSmoothie.calcPrice() && 
				this.getNumOfFruits() == tempSmoothie.getNumOfFruits() &&
				this.getAddProtein() == tempSmoothie.getAddProtein())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public double calcPrice()
	{
		double smoothiePrice = 0;
		smoothiePrice += super.addSizePrice();
		smoothiePrice += (numberOfFruits * COST_OF_ADDITIONAL_FRUIT);
		
		if(isProteinPowderAddedToBeverage)
		{
			smoothiePrice += COST_OF_PROTIEN;
		}

		return smoothiePrice;
	}
	
	public int getNumOfFruits()
	{
		return numberOfFruits;
	}
	public boolean getAddProtein()
	{
		return isProteinPowderAddedToBeverage;
	}
}
