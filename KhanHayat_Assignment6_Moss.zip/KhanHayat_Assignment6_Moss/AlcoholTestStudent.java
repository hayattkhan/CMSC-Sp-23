/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AlcoholTestStudent 
{
	Alcohol alcoholOne;
	Alcohol alcoholTwo;
	Alcohol alcoholThree;
	//creating this copy for checking if it is same as the first Alcohol
	Alcohol copyOne;

	@BeforeEach
	void setUp() throws Exception 
	{
		alcoholOne = new Alcohol("Tequilla", Size.SMALL, false);
		alcoholTwo = new Alcohol("Wine", Size.MEDIUM, true);
		alcoholThree = new Alcohol("Vodka", Size.LARGE, true);
		//true copy of smoothieOne
		copyOne = new Alcohol("Tequilla", Size.SMALL, false);
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		alcoholOne = null;
		alcoholTwo = null;
		alcoholThree = null;
		copyOne = null;
	}

	@Test
	void testIsWeekend()
	{
		assertEquals(false, alcoholOne.isWeekend());
		assertEquals(true, alcoholTwo.isWeekend());
		assertEquals(true, alcoholThree.isWeekend());
	}
	
	@Test
	void testCalcPrice()
	{
		assertEquals(2.0, alcoholOne.calcPrice());
		assertEquals(3.6, alcoholTwo.calcPrice());
		assertEquals(4.6, alcoholThree.calcPrice());
	}
	
	@Test
	void testToString()
	{
		assertEquals("Tequilla,SMALL,false,2.0", alcoholOne.toString());
		assertEquals("Wine,MEDIUM,true,3.6", alcoholTwo.toString());
		assertEquals("Vodka,LARGE,true,4.6", alcoholThree.toString());
	}
	
	@Test
	void testEquals()
	{
		assertEquals(false, alcoholOne.equals(alcoholTwo));
		assertEquals(false, alcoholOne.equals(alcoholThree));
		assertEquals(false, alcoholTwo.equals(alcoholThree));
		assertEquals(true, alcoholOne.equals(copyOne));
	}
}
