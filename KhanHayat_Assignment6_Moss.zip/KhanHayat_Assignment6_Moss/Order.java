/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import java.util.ArrayList;
import java.util.Random;

public class Order implements OrderInterface, Comparable<Order>
{
	private int orderNumber;
	private int orderTime;
	Day orderDay;
	Customer visitor;
	ArrayList<Beverage> listOfBeverages;

	
	public Order(int orderTime, Day orderDay, Customer cust)
	{
		//passers
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.visitor = new Customer(cust); 
		//set ups
		orderNumber = generateOrder();
		listOfBeverages = new ArrayList<Beverage>();
	}
	
	public int generateOrder()
	{
		int randomNumber;
		Random randomGenerator = new Random();
		randomNumber = randomGenerator.nextInt(80000);
		randomNumber += 10000;
		//add 1 because 0 is a thing
		randomNumber += 1;
		return randomNumber;
	}
	
	//getters
	public int getOrderNo()
	{
		return orderNumber;
	}
	public int getOrderTime()
	{
		return orderTime;
	}
	public Day getOrderDay()
	{
		return orderDay;	
	}
	public Customer getCustomer()
	{
		return new Customer(visitor);
	}
	public Day getDay()
	{
		return orderDay;
	}
	@Override
	public boolean isWeekend()
	{
		switch (orderDay)
		{
			case SATURDAY:
			case SUNDAY:
			{
				return true;
			}
			default:
			{
				return false;
			}
		}	
	}
	@Override
	public Beverage getBeverage(int itemNo)
	{
		if (itemNo >= listOfBeverages.size()) 
		{
			return null;
		}

		return listOfBeverages.get(itemNo);
	}
	
	public int getTotalItems()
	{
		return listOfBeverages.size();
	}
	
	//overloaded and overridden addNewBeverage methods
	//adds a new coffee order to this order
	@Override
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup)
	{
		Coffee newCoffee = new Coffee(bevName, size, extraShot, extraSyrup);
		listOfBeverages.add(newCoffee);
	}
	//adds a new alcohol  order to this order
	@Override
	public void addNewBeverage(String bevName, Size size)
	{
		Alcohol newAlcohol = new Alcohol(bevName, size, this.isWeekend());
		listOfBeverages.add(newAlcohol);
	}
	//adds a new smoothie order to this order
	@Override
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein)
	{
		Smoothie newSmoothie = new Smoothie(bevName, size, numOfFruits, addProtein);
		listOfBeverages.add(newSmoothie);
	}
	
	@Override
	public double calcOrderTotal()
	{
		double calculatedTotal = 0.0;
		
		for(int index = 0; index < listOfBeverages.size(); index++)
		{
			calculatedTotal += listOfBeverages.get(index).calcPrice();
		}
		
		return calculatedTotal;
	}
	
	@Override
	public int findNumOfBeveType(Type type)
	{
		int beverageTotal = 0;
		
		for(int index = 0; index < listOfBeverages.size(); index++)
		{
			if(type.equals(listOfBeverages.get(index).getType()))
			{
				beverageTotal++;
			}
		}
		
		return beverageTotal;
	}
	
	@Override
	public String toString()
	{
		String tempString = orderNumber + "," + orderTime + "," + orderDay + "," + this.visitor + "," + this.listOfBeverages;
		/*
		for(int index = 0; index < listOfBeverages.size(); index++)
		{
			tempString += 
		}
		*/
		
		return tempString;
	}
	
	@Override
	public int compareTo(Order anotherOrder)
	{
		if(this.orderNumber == anotherOrder.getOrderNo())
		{
			return 0;
		}
		else if(this.orderNumber > anotherOrder.getOrderNo())
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
}
