/*
 * Class: CMSC203 
 * Instructor: prof. Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OrderTestStudent 
{
	Order orderOne;
	Order orderTwo;
	Order orderThree;
	Order orderFour;

	@BeforeEach
	void setUp() throws Exception 
	{
		orderOne = new Order(1, Day.MONDAY, new Customer("Bob", 17));
		orderTwo = new Order(5, Day.FRIDAY, new Customer("Tom", 30));
		orderThree = new Order(6, Day.SATURDAY, new Customer("Jeff", 21));
		orderFour = new Order (11, Day.SUNDAY, new Customer("Billy",15));
		
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		orderOne = null;
		orderTwo = null;
		orderThree = null;
		orderFour = null;
	}

	@Test
	void testGetOrderNo()
	{
		assertEquals(1, orderOne.getOrderTime());
		assertEquals(5, orderTwo.getOrderTime());
		assertEquals(6, orderThree.getOrderTime());
		assertEquals(11, orderFour.getOrderTime());
	}
	
	@Test
	void testGetOrderDay()
	{
		assertEquals(Day.MONDAY, orderOne.getOrderDay());
		assertEquals(Day.FRIDAY, orderTwo.getOrderDay());
		assertEquals(Day.SATURDAY, orderThree.getOrderDay());
		assertEquals(Day.SUNDAY, orderFour.getOrderDay());
	}
	
	@Test
	void testGetCustomer()
	{
		assertEquals("Bob,17", orderOne.getCustomer().toString());
		assertEquals("Tom,30", orderTwo.getCustomer().toString());
		assertEquals("Ali,21", orderThree.getCustomer().toString());
		assertEquals("Billy,15", orderFour.getCustomer().toString());
	}
	
	@Test
	void testGetDay()
	{
		assertEquals(Day.MONDAY, orderOne.getDay());
		assertEquals(Day.FRIDAY, orderTwo.getDay());
		assertEquals(Day.SATURDAY, orderThree.getDay());
		assertEquals(Day.SUNDAY, orderFour.getDay());
	}
	
	@Test
	void testIsWeekend()
	{
		assertEquals(false, orderOne.isWeekend());
		assertEquals(false, orderTwo.isWeekend());
		assertEquals(true, orderThree.isWeekend());
		assertEquals(true, orderFour.isWeekend());
	}
	
	@Test
	void testGetBeverage()
	{
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		assertTrue(orderOne.getBeverage(0).getType().equals(Type.COFFEE));
		
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		assertTrue(orderOne.getBeverage(1).getType().equals(Type.ALCOHOL));
		
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		assertTrue(orderOne.getBeverage(2).getType().equals(Type.SMOOTHIE));
		
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);
		assertTrue(orderOne.getBeverage(3).getType().equals(Type.SMOOTHIE));
	}
	
	@Test
	void testGetTotalItems()
	{
		assertTrue(orderOne.getTotalItems() == 0);
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);
		assertTrue(orderOne.getTotalItems() == 4);
	}	
	
	@Test
	public void testAddNewBeverage() throws NullPointerException 
	{
		assertTrue(orderOne.getTotalItems() == 0);
		
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		assertTrue(orderOne.getBeverage(0).getType().equals(Type.COFFEE));
		
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		assertTrue(orderOne.getBeverage(1).getType().equals(Type.ALCOHOL));
		
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		assertTrue(orderOne.getBeverage(2).getType().equals(Type.SMOOTHIE));
		
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);
		assertTrue(orderOne.getBeverage(3).getType().equals(Type.SMOOTHIE));
		
		assertTrue(orderOne.getTotalItems() == 4);
	}
	
	@Test
	public void testCalcOrderTotal() 
	{
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);
		
		//System.out.println(orderOne.calcOrderTotal());

		assertEquals(18.0, orderOne.calcOrderTotal(),0.0);

		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, false, true);
		
		//System.out.println(orderTwo.calcOrderTotal());

		assertEquals(27.5, orderTwo.calcOrderTotal(), .01);
		
		orderThree.addNewBeverage("Mohito", Size.LARGE);
		orderThree.addNewBeverage("Mohito", Size.SMALL);
		orderThree.addNewBeverage("Mohito", Size.MEDIUM);
		orderThree.addNewBeverage("Mohito", Size.MEDIUM);
		orderThree.addNewBeverage("Mohito", Size.LARGE);
		orderThree.addNewBeverage("Mohito", Size.LARGE);
		
		//System.out.println(orderThree.calcOrderTotal());

		assertEquals(23.6, orderThree.calcOrderTotal(),0.0);
		
		orderFour.addNewBeverage("Detox", Size.LARGE, 1, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 1, false);
		orderFour.addNewBeverage("Detox", Size.MEDIUM, 2, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 99, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 2, false);
		orderFour.addNewBeverage("Detox", Size.LARGE, 12, true);
		orderFour.addNewBeverage("Detox", Size.SMALL, 2, true);
		orderFour.addNewBeverage("Detox", Size.SMALL, 2, false);
		
		//System.out.println(orderFour.calcOrderTotal());

		assertEquals(95.0, orderFour.calcOrderTotal(),0.0);
	}
	
	@Test
	void testFindNumOfBeveType()
	{
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);

		assertEquals(2, orderOne.findNumOfBeveType(Type.SMOOTHIE),0.0);

		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderTwo.addNewBeverage("Chai Latte", Size.MEDIUM, false, true);

		assertEquals(7, orderTwo.findNumOfBeveType(Type.COFFEE),0.0);
		
		orderThree.addNewBeverage("Mohito", Size.LARGE);
		orderThree.addNewBeverage("Mohito", Size.SMALL);
		orderThree.addNewBeverage("Mohito", Size.MEDIUM);
		orderThree.addNewBeverage("Mohito", Size.MEDIUM);
		orderThree.addNewBeverage("Mohito", Size.LARGE);
		orderThree.addNewBeverage("Mohito", Size.LARGE);

		assertEquals(6, orderThree.findNumOfBeveType(Type.ALCOHOL),0.0);
		
		orderFour.addNewBeverage("Detox", Size.LARGE, 1, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 1, false);
		orderFour.addNewBeverage("Detox", Size.MEDIUM, 2, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 99, true);
		orderFour.addNewBeverage("Detox", Size.LARGE, 2, false);
		orderFour.addNewBeverage("Detox", Size.LARGE, 12, true);
		orderFour.addNewBeverage("Mohito", Size.SMALL);
		orderFour.addNewBeverage("Detox", Size.SMALL, 2, true);
		orderFour.addNewBeverage("Detox", Size.SMALL, 2, false);

		assertEquals(8, orderFour.findNumOfBeveType(Type.SMOOTHIE),0.0);
	}	
	
	@Test
	void testToString()
	{
		orderOne.addNewBeverage("Chai Latte", Size.MEDIUM, true, true);
		orderOne.addNewBeverage("Mohito", Size.LARGE);
		orderOne.addNewBeverage("Detox", Size.LARGE, 2, true);
		orderOne.addNewBeverage("Detox", Size.SMALL, 3, false);
		
		//System.out.println(orderOne.toString());
		
		assertEquals(orderOne.getOrderNo() + "," +"1,MONDAY,Bob,17,[Chai Latte,MEDIUM,true,true,4.0, Mohito,LARGE,false,4.0, Detox,LARGE,true,2,6.5, Detox,SMALL,false,3,3.5]", orderOne.toString());
	}
	
	@Test
	void testCompareTo()
	{
		if(orderOne.getOrderNo() == orderTwo.getOrderNo())
		{
			assertEquals(0, orderOne.compareTo(orderTwo));
		}
		else if(orderOne.getOrderNo() > orderTwo.getOrderNo())
		{
			assertEquals(1, orderOne.compareTo(orderTwo));
		}
		else
		{
			assertEquals(-1, orderOne.compareTo(orderTwo));
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
