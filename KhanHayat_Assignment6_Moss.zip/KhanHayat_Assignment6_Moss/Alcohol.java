/*
 * Class: CMSC203 
 * Instructor: Prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public class Alcohol extends Beverage
{
	private boolean isItWeekend;
	
	private final double ADDITIONAL_COST_FOR_WEEKEND = 0.60; //$0.60
	
	
	
	public Alcohol(String bevName, Size size, boolean isWeekend)
	{
		super(bevName, Type.ALCOHOL, size);
		isItWeekend = isWeekend;
	}

	@Override
	public String toString()
	{
		return super.toString() + "," + this.isWeekend() + "," + calcPrice();
	}
	
	@Override
	public boolean equals(Object anotherBev)
	{
		Alcohol tempAlcohol = (Alcohol) anotherBev;
		
		if(super.equals(tempAlcohol) &&
				this.calcPrice() == tempAlcohol.calcPrice() &&
				this.isItWeekend == tempAlcohol.isWeekend())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public double calcPrice()
	{
		double alcoholPrice = 0;
		alcoholPrice += super.addSizePrice();
		
		if(isItWeekend)
		{
			alcoholPrice += ADDITIONAL_COST_FOR_WEEKEND;
		}
		
		return alcoholPrice;
	}
	
	public boolean isWeekend()
	{
		if(isItWeekend)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
