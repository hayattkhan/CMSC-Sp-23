/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 7/5/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public abstract class Beverage 
{
	//fields
	private String bevName;
	private Type type;
	private Size size;
	//constants
	private final double BASE_PRICE = 2.0; //$2.00
	private final double SIZE_PRICE = 1.0; //$1.00 to go a size up
	
	//A parametrized constructor to create a Beverage object given its name, type and size
	Beverage(String bevName, Type type, Size size)
	{
		this.bevName = bevName;
		this.type = type;
		this.size = size;
	}
	
	//An abstract method called calcPrice that calculates and returns the beverage price
	public abstract double calcPrice();
	
	//A toString method: String representation for Beverage including the name and size
	@Override
	public String toString()
	{
		return bevName + "," + size;
	}
	
	//An Overridden equals method: checks equality based on name, type, size of the beverage
	@Override
	public boolean equals(Object anotherBev)
	{
		Beverage tempNew = (Beverage) anotherBev;
		
		if(this.bevName.equals(tempNew.bevName) && type.equals(tempNew.type) && size.equals(tempNew.size))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//getters and setters and any other methods that are needed for your design
	//getters
	public String getBevName()
	{
		return bevName;
	}
	public Type getType()
	{
		return type;
	}
	public Size getSize()
	{
		return size;
	}
	public double getBasePrice()
	{
		return BASE_PRICE;
	}
	public double getSizePrice()
	{
		return SIZE_PRICE;
	}
	//setters

	
	/*
	//Calculates a new price by adding the size price to the base price. 
	//There is no additional cost for small size, 
	//for medium and large beverages the additional cost of size price is added to base price 
	
	For example if the base price is 2 and SIZE_PRICE is .5 then the cost of small beverage is 2, the medium beverage is 2.5 and the large beverage is 3.
	*/
	public double addSizePrice()
	{
		double newPrice = 0.0;
		
		if(size.equals(Size.SMALL))
		{
			newPrice = BASE_PRICE;
			return newPrice;
		}
		else if(size.equals(Size.MEDIUM))
		{
			newPrice = BASE_PRICE + SIZE_PRICE;
			return newPrice;
		}
		else if(size.equals(Size.LARGE))
		{
			newPrice = BASE_PRICE + (SIZE_PRICE * 2);
			return newPrice;
		}
		else
		{
			return 0.0;
		}
	}
}
