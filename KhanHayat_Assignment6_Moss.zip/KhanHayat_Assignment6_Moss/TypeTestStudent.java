/*
 * Class: CMSC203 
 * Instructor: prof. Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TypeTestStudent 
{
	Type coffee;
	Type smoothie;
	Type alcohol;

	@BeforeEach
	void setUp() throws Exception 
	{
		coffee = Type.COFFEE;
		smoothie = Type.SMOOTHIE;
		alcohol = Type.ALCOHOL;
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		coffee = null;
		smoothie = null;
		alcohol = null;
	}

	@Test
	void testCoffee() 
	{
		assertEquals(Type.valueOf("COFFEE"), coffee);
	}
	
	@Test
	void testSmoothie() 
	{
		assertEquals(Type.valueOf("SMOOTHIE"), smoothie);
	}
	
	@Test
	void testAlcohol() 
	{
		assertEquals(Type.valueOf("ALCOHOL"), alcohol);
	}

}
