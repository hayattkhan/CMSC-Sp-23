/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SmoothieTestStudent
{
	Smoothie smoothieOne;
	Smoothie smoothieTwo;
	Smoothie smoothieThree;
	//creating this smoothie for checking if it is same as the first Smoothie
	Smoothie copyOne;

	@BeforeEach
	void setUp() throws Exception 
	{
		smoothieOne = new Smoothie("Mango", Size.SMALL, 2, false);
		smoothieTwo = new Smoothie("Banana", Size.MEDIUM, 0, true);
		smoothieThree = new Smoothie("Strawberry", Size.LARGE, 50, true);
		//true copy of smoothieOne
		copyOne = new Smoothie("Mango", Size.SMALL, 2, false);
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		smoothieOne = null;
		smoothieTwo = null;
		smoothieThree = null;
		copyOne = null;
	}

	@Test
	void testGetNumOfFruits() 
	{
		assertEquals(2, smoothieOne.getNumOfFruits());
		assertEquals(0, smoothieTwo.getNumOfFruits());
		assertEquals(50, smoothieThree.getNumOfFruits());
	}
	
	@Test
	void testGetAddProtein()
	{
		assertEquals(false, smoothieOne.getAddProtein());
		assertEquals(true, smoothieTwo.getAddProtein());
		assertEquals(true, smoothieThree.getAddProtein());
	}
	
	@Test
	void testCalcPrice()
	{
		assertEquals(3.0, smoothieOne.calcPrice());
		assertEquals(4.5, smoothieTwo.calcPrice());
		assertEquals(30.5, smoothieThree.calcPrice());
	}
	
	@Test
	void testToString()
	{
		assertEquals("Mango,SMALL,false,2,3.0", smoothieOne.toString());
		assertEquals("Banana,MEDIUM,true,0,4.5", smoothieTwo.toString());
		assertEquals("Strawberry,LARGE,true,50,30.5", smoothieThree.toString());
	}
	
	@Test
	void testEquals()
	{
		assertEquals(false, smoothieOne.equals(smoothieTwo));
		assertEquals(false, smoothieOne.equals(smoothieThree));
		assertEquals(false, smoothieTwo.equals(smoothieThree));
		assertEquals(true, smoothieOne.equals(copyOne));
	}
}
