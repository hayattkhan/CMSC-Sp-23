/*
 * Class: CMSC203 
 * Instructor: prof. Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerTestStudent 
{

	Customer customerOne;
	Customer customerTwo;
	Customer customerThree;

	@BeforeEach
	void setUp() throws Exception 
	{
		customerOne = new Customer("John Doe",27);
		customerTwo = new Customer("George Washington",18);
		customerThree = new Customer("Tom Bobby",10);
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		customerOne = null;
		customerTwo = null;
		customerThree = null;
	}

	@Test
	void testGetName() 
	{
		assertEquals("John Doe", customerOne.getName());
		assertEquals("George Washington", customerTwo.getName());
		assertEquals("Tom Bobby", customerThree.getName());
	}
	@Test
	void testSetName() 
	{
		customerOne.setName("ALEX DAVE");
		assertEquals(true,customerOne.getName().equals("ALEX DAVE"));
		
		customerTwo.setName("ALEX CAVE");
		assertEquals(true,customerTwo.getName().equals("ALEX CAVE"));
		
		customerThree.setName("ALEX BANE");
		assertEquals(true,customerThree.getName().equals("ALEX BANE"));
	}
	
	@Test
	void testGetAge() 
	{
		assertEquals(27, customerOne.getAge());
		assertEquals(18, customerTwo.getAge());
		assertEquals(10, customerThree.getAge());
	}
	@Test
	void testSetAge()
	{
		customerOne.setAge(5);
		assertEquals(5, customerOne.getAge());
		
		customerTwo.setAge(20);
		assertEquals(20, customerTwo.getAge());
		
		customerThree.setAge(19);
		assertEquals(19, customerThree.getAge());
	}
	
	@Test
	void testToString()
	{
		assertEquals("John Doe,27", customerOne.toString());
		assertEquals("George Washington,18", customerTwo.toString());
		assertEquals("Tom Bobby,10", customerThree.toString());
	}

}
