/*
 * Class: CMSC203 
 * Instructor: prof. Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

public enum Day
{
	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}
