/*
 * Class: CMSC203 
 * Instructor: Prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SizeTestStudent 
{
	Size small;
	Size medium;
	Size large;

	@BeforeEach
	void setUp() throws Exception 
	{
		small = Size.SMALL;
		medium = Size.MEDIUM;
		large = Size.LARGE;
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		small = null;
		medium = null;
		large = null;
	}

	@Test
	void testSmall() 
	{
		assertEquals(Size.valueOf("SMALL"), small);
	}
	
	@Test
	void testMedium() 
	{
		assertEquals(Size.valueOf("MEDIUM"), medium);
	}
	
	@Test
	void testLarge() 
	{
		assertEquals(Size.valueOf("LARGE"), large);
	}

}
