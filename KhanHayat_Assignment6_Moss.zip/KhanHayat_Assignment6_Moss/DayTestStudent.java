/*
 * Class: CMSC203 
 * Instructor: prof. Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/7/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DayTestStudent
{
	Day sunday;
	Day monday;
	Day tuesday;
	Day wednesday;
	Day thursday;
	Day friday;
	Day saturday;

	@BeforeEach
	void setUp() throws Exception 
	{
		sunday = Day.SUNDAY;
		monday = Day.MONDAY;
		tuesday = Day.TUESDAY;
		wednesday = Day.WEDNESDAY;
		thursday = Day.THURSDAY;
		friday = Day.FRIDAY;
		saturday = Day.SATURDAY;
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		sunday = null;
		monday = null;
		tuesday = null;
		wednesday = null;
		thursday = null;
		friday = null;
		saturday = null;
	}

	@Test
	void testSunday() 
	{
		assertEquals(Day.valueOf("SUNDAY"), sunday);
	}
	
	@Test
	void testMonday() 
	{
		assertEquals(Day.valueOf("MONDAY"), monday);
	}
	
	@Test
	void testTuesday() 
	{
		assertEquals(Day.valueOf("TUESDAY"), tuesday);
	}
	
	@Test
	void testWednesday() 
	{
		assertEquals(Day.valueOf("WEDNESDAY"), wednesday);
	}
	
	@Test
	void testThursday() 
	{
		assertEquals(Day.valueOf("THURSDAY"), thursday);
	}
	
	@Test
	void testFriday() 
	{
		assertEquals(Day.valueOf("FRIDAY"), friday);
	}
	
	@Test
	void testSaturday() 
	{
		assertEquals(Day.valueOf("SATURDAY"), saturday);
	}

}
