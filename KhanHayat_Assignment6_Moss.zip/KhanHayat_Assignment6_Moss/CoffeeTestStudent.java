/*
 * Class: CMSC203 
 * Instructor: prof.Monshi
 * Description: The BevShop offers 3 types of beverages: Coffee, Alcoholic and Smoothie. 
 * 		Beverages can be ordered in 3 different sizes: Small, medium and large. 
 * 		All the beverage types has a base price. 
 * 		In addition, there are additional charges depending on the size and specific add-ons for each type of beverage.  
 * Due: 5/77/2023
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Hayatullah Khan
*/

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CoffeeTestStudent 
{
	Coffee coffeeOne;
	Coffee coffeeTwo;
	Coffee coffeeThree;
	//creating this coffee for checking if it is same as the first Coffee
	Coffee copyOne;

	@BeforeEach
	void setUp() throws Exception 
	{
		coffeeOne = new Coffee("Chai Latte", Size.SMALL, false, false);
		coffeeTwo = new Coffee("Pumpkin Spice Latte", Size.MEDIUM, false, true);
		coffeeThree = new Coffee("Espresso", Size.LARGE, true, true);
		//true copy of coffeeOne
		copyOne = new Coffee("Chai Latte", Size.SMALL, false, false);
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		coffeeOne = null;
		coffeeTwo = null;
		coffeeThree = null;
		copyOne = null;
	}

	@Test
	void testGetExtraShot() 
	{
		assertEquals(false, coffeeOne.getExtraShot());
		assertEquals(false, coffeeTwo.getExtraShot());
		assertEquals(true, coffeeThree.getExtraShot());
	}
	
	@Test
	void testGetExtraSyrup()
	{
		assertEquals(false, coffeeOne.getExtraSyrup());
		assertEquals(true, coffeeTwo.getExtraSyrup());
		assertEquals(true, coffeeThree.getExtraSyrup());
	}
	
	@Test
	void testCalcPrice()
	{
		assertEquals(2, coffeeOne.calcPrice());
		assertEquals(3.5, coffeeTwo.calcPrice());
		assertEquals(5, coffeeThree.calcPrice());
	}
	
	@Test
	void testToString()
	{
		assertEquals("Chai Latte,SMALL,false,false,2.0", coffeeOne.toString());
		assertEquals("Pumpkin Spice Latte,MEDIUM,false,true,3.5", coffeeTwo.toString());
		assertEquals("Espresso,LARGE,true,true,5.0", coffeeThree.toString());
	}
	
	@Test
	void testEquals()
	{
		assertEquals(false, coffeeOne.equals(coffeeTwo));
		assertEquals(false, coffeeOne.equals(coffeeThree));
		assertEquals(false, coffeeTwo.equals(coffeeThree));
		assertEquals(true, coffeeOne.equals(copyOne));
	}
	

}
